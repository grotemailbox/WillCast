package com.htmltoapk.xyz

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket
import java.net.NetworkInterface
import java.util.concurrent.Executors

/**
 * Small LAN HTTP server for casting a selected local video.
 * Supports PUT /upload and GET /video (including HTTP byte ranges for seeking).
 */
class CastMediaServer(context: Context) {
    private val file = File(context.cacheDir, "willcast-current-media")
    @Volatile private var server: ServerSocket? = null
    @Volatile private var running = false
    private val workers = Executors.newCachedThreadPool()
    @Volatile private var contentType = "video/mp4"

    @Synchronized fun start(): String {
        if (server == null) {
            val socket = ServerSocket(0)
            server = socket
            running = true
            Thread {
                while (running) {
                    try {
                        val client = socket.accept()
                        workers.execute { handle(client) }
                    } catch (_: Exception) { if (running) break }
                }
            }.start()
        }
        val ip = localIpv4() ?: throw IllegalStateException("Geen wifi-netwerkadres gevonden")
        return "http://$ip:${server!!.localPort}/video"
    }

    fun setMime(value: String) {
        contentType = value.takeIf { it.startsWith("video/") || it.startsWith("audio/") } ?: "video/mp4"
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 120000
                val input = BufferedInputStream(s.getInputStream())
                val output = BufferedOutputStream(s.getOutputStream())
                val request = readLine(input) ?: return
                val parts = request.split(" ")
                if (parts.size < 2) return
                val method = parts[0]
                val path = parts[1]
                val headers = linkedMapOf<String, String>()
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    val ix = line.indexOf(':')
                    if (ix > 0) headers[line.substring(0, ix).trim().lowercase()] = line.substring(ix + 1).trim()
                }
                if (method == "OPTIONS") {
                    output.write("HTTP/1.1 204 No Content\\r\\nAccess-Control-Allow-Origin: *\\r\\nAccess-Control-Allow-Methods: GET, PUT, OPTIONS\\r\\nAccess-Control-Allow-Headers: Content-Type\\r\\nAccess-Control-Max-Age: 600\\r\\nContent-Length: 0\\r\\nConnection: close\\r\\n\\r\\n".toByteArray())
                    output.flush()
                    return
                }
                if (method == "PUT" && path == "/upload") {
                    val length = headers["content-length"]?.toLongOrNull() ?: 0L
                    if (length <= 0 || length > 8L * 1024 * 1024 * 1024) {
                        respond(output, "400 Bad Request", "Ongeldige bestandsgrootte")
                        return
                    }
                    file.outputStream().buffered().use { dest ->
                        val buffer = ByteArray(64 * 1024)
                        var remaining = length
                        while (remaining > 0) {
                            val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                            if (n < 0) throw IllegalStateException("Upload afgebroken")
                            dest.write(buffer, 0, n)
                            remaining -= n
                        }
                    }
                    respond(output, "200 OK", "OK")
                    return
                }
                if (method != "GET" || path != "/video" || !file.exists()) {
                    respond(output, "404 Not Found", "Geen video beschikbaar")
                    return
                }
                val size = file.length()
                val range = headers["range"]
                var start = 0L
                var end = size - 1
                var partial = false
                if (range != null && range.startsWith("bytes=")) {
                    val pair = range.removePrefix("bytes=").split("-", limit = 2)
                    start = pair[0].toLongOrNull() ?: 0L
                    end = pair.getOrNull(1)?.toLongOrNull() ?: end
                    if (start >= size || end < start) {
                        output.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$size\r\nConnection: close\r\n\r\n".toByteArray())
                        output.flush()
                        return
                    }
                    end = minOf(end, size - 1)
                    partial = true
                }
                val count = end - start + 1
                val status = if (partial) "206 Partial Content" else "200 OK"
                output.write(("HTTP/1.1 $status\r\nContent-Type: $contentType\r\nAccept-Ranges: bytes\r\nContent-Length: $count\r\n" +
                    (if (partial) "Content-Range: bytes $start-$end/$size\r\n" else "") +
                    "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n").toByteArray())
                file.inputStream().use { src ->
                    src.skip(start)
                    val buffer = ByteArray(64 * 1024)
                    var remaining = count
                    while (remaining > 0) {
                        val n = src.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        remaining -= n
                    }
                }
                output.flush()
            } catch (_: Exception) { }
        }
    }

    private fun respond(out: BufferedOutputStream, status: String, body: String) {
        val bytes = body.toByteArray()
        out.write("HTTP/1.1 $status\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun readLine(input: BufferedInputStream): String? {
        val b = ArrayList<Byte>()
        while (b.size < 8192) {
            val c = input.read()
            if (c < 0) return if (b.isEmpty()) null else b.toByteArray().toString(Charsets.UTF_8)
            if (c == 10) break
            if (c != 13) b.add(c.toByte())
        }
        return b.toByteArray().toString(Charsets.UTF_8)
    }

    private fun localIpv4(): String? {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        val all = mutableListOf<NetworkInterface>()
        while (interfaces.hasMoreElements()) all.add(interfaces.nextElement())
        val ordered = all.sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("ap")) 0 else 1 }
        for (ni in ordered) {
            if (!ni.isUp || ni.isLoopback) continue
            val addresses = ni.inetAddresses
            while (addresses.hasMoreElements()) {
                val a = addresses.nextElement()
                if (!a.isLoopbackAddress && a.hostAddress?.contains(':') == false) return a.hostAddress
            }
        }
        return null
    }

    @Synchronized fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        server = null
    }
}
