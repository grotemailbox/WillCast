# WillCast – Chromecast build

Deze projectversie voegt de Google Cast Sender SDK toe en verstuurt een gekozen videobestand via een tijdelijke HTTP-stream vanaf de telefoon naar een Cast-tv.

## Bouwen
1. Pak deze ZIP uit op een computer met Android Studio.
2. Open de map van het project in Android Studio.
3. Laat Gradle synchroniseren (internet nodig om de Google Cast SDK 23.0.0 op te halen).
4. Kies **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Installeer de gemaakte APK op de Samsung.

## Gebruiken
- Telefoon en Sony-tv moeten op hetzelfde wifi-netwerk zitten.
- Open WillCast, kies een video en druk op **Chromecast**.
- De app uploadt de video via het lokale wifi-netwerk naar de telefoonserver, opent daarna het Cast-keuzemenu en start de video zodra de tv is gekozen.
- De stream ondersteunt HTTP byte ranges voor vooruit/terug zoeken.
- De tv start gedempt; gebruik de volumebediening in WillCast of de tv.

## Grenzen / test
- Dit is een aangepaste Android Studio-projectbron, geen vooraf gebouwde APK.
- De broncode kon in deze omgeving niet met Android Gradle Plugin/SDK worden gebouwd of op een Sony-tv worden getest.
- De Google Default Media Receiver is bedoeld voor eenvoudige mediaweergave. MP4 met H.264-video en AAC-audio is de veiligste keuze; niet elk videoformaat of elke codec wordt door de tv ondersteund.
- De telefoon moet tijdens het casten aan blijven en op hetzelfde netwerk blijven. De tijdelijke streamserver stopt wanneer WillCast wordt afgesloten.
